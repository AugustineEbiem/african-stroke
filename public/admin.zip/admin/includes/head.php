
	<meta charset="UTF-8">
	<title>Africa Stroke Organization |  Admin </title>
	<meta name="keywords" content="Africa Stroke  Organization" />
	<meta name="description" content="Africa  Stroke  Organization">
	<meta name="author" content="Vocett Technologies">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,300,400,600,700,800,900" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css" />
	<link rel="stylesheet" href="vendor/animate/animate.compat.css">
	<link rel="stylesheet" href="vendor/font-awesome/css/all.min.css" />
	<link rel="stylesheet" href="vendor/boxicons/css/boxicons.min.css" />
	<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" />
	<link rel="stylesheet" href="vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />
	<link rel="stylesheet" href="vendor/morris/morris.css" /> <link rel="stylesheet" href="vendor/datatables/media/css/dataTables.bootstrap4.css" />
	<link rel="stylesheet" href="css/theme.css" />
	<link rel="stylesheet" href="css/layouts/modern.css" />
	<link rel="stylesheet" href="css/custom.css">
	<script src="vendor/modernizr/modernizr.js"></script> 
	<script src="master/style-switcher/style.switcher.localstorage.js"></script>
</head>
</html>