            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <ul>
                        	<li class="menu-title">Navigation</li>

                            <li class="has_sub">
                                <a href="dashboard.php" class="waves-effect"><i class="fa fa-home"></i> <span> Dashboard </span> </a>
                         
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-tag"></i> <span> Category </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="add-category.php">Add Category</a></li>
                                    <li><a href="manage-categories.php">Manage Category</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-key"></i> <span>Sub Category </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-subcategory.php">Add Sub Category</a></li>
                                    <li><a href="manage-subcategories.php">Manage Sub Category</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect  active"><i class="fa fa-book"></i> <span> Journals </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="new_journal.php">Add Journal</a></li>
                                    <li><a href="journals.php">Manage Journals</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-tv"></i> <span> Blogs </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<li><a href="new_blog.php">New Blog</a></li>
                                    <li><a href="blogs.php">Manage Blogs</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-suitcase"></i> <span> Resources </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                	<!--<li><a href="new_resource.php">Add Resource</a></li>-->
                                    <li><a href="resources.php">Resources</a></li>
                                </ul>
                            </li>
                            
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-sticky-note"></i> <span> News </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add-post.php">Add News</a></li>
                                    <li><a href="manage-posts.php">Manage News</a></li>
                                </ul>
                            </li> 
                             <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-image"></i> <span> Gallery </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="add_photo.php">Add Photo</a></li>
                                    <li><a href="gallery.php">Manage Gallery</a></li>
                                </ul>
                            </li> 
                            
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-users"></i> <span> Membership </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="new_member.php">Add Member</a></li>
                                    <li><a href="members.php">Manage Members </a></li>
                                     
                                </ul>
                            </li>  
                     

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Pages </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="aboutus.php">About us</a></li>
                                    <li><a href="contactus.php">Contact us</a></li>
                                    <?php /* <li><a class="nav-link" href="overview.php"> - Overview</a></li>
                                    <li><a class="nav-link" href="bec.php"> - Board ive</a></li>
                                    <li><a class="nav-link" href="overview.php"> - Overview</a></li>
                                    <li><a class="nav-link" href="committee.php"> -s</a></li>
                                    <li><a class="nav-link" href="taskforces.php"> - Taskforces</a></li>
                                    <li><a class="nav-link" href="members.php"s</a></li>
                                    <li><a class="nav-link" href="bylaws.php"> - Bylaws</a></li>
                                    <li><a class="nav-link" href="bec.php"></a></a></li>
                                    <li><a class="nav-link" href="overview.php"> - Annual Report</a></li>
                                    <li><a class="nav-link" href="bec.php"> - President</a></li>
                                    <li><a class="nav-link" href="overview.php"> - Secreteriat</a></li>
                                    <li><a class="nav-link" href="bec.php"</a></li>
                                    <li><a class="nav-link" href="bec.php"> -Partners</a></li>
                                    <li><a class="nav-link" href="bec.php"> -Partnership/Funding</a></li>
                                    <li><a class="nav-link" href="bec.php"> - Resources/Journal</a></li>
                                    <li><a class="nav-link" href="bec.php"> -Podcasts</a></li>
                                    <li><a class="nav-link" href="bec.php"> -News</a></li>
                                    <li><a class="nav-link" href="bec.php"> -Blog</a></li>
                                    <li><a class="nav-link" href="bec.php"> -Newsletters</a></li> */?>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-comment-o"></i> <span> Comments </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                  <li><a href="unapprove-comment.php">Waiting for Approval </a></li>
                                    <li><a href="manage-comments.php">Approved Comments</a></li>
                                </ul>
                            </li>   
                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-users"></i> <span> Users </span> <span class="menu-arrow"></span></a>
                                <ul class="list-unstyled">
                                  <li><a href="add_user.php">Add User </a></li>
                                    <li><a href="users.php"> Manage Users</a></li>
                                </ul>
                            </li>   

                        </ul>
                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                    <?php /*<div class="help-box">
                        <h5 class="text-muted m-t-0">For Help ?</h5>
                        <p class=""><span class="text-custom">Email:</span> <br/></p>
                    </div> */?>

                </div>
                <!-- Sidebar -left -->

            </div>