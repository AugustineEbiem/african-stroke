<?php

$server_name = "81.19.215.8";
$server_user = "african2";
$server_pass = "VGE17dV(7b!t8b";
$server_db = "african2_db";



$conn = new mysqli($server_name,$server_user,$server_pass,$server_db) or die("Could not connect...".mysqli_error);

?>